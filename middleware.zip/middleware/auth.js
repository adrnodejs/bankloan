import jwt from 'jsonwebtoken';
import constants from '../constant';

const auth = (req, res, next) => {
    const token = req.header('auth');
    if (!token) {
        return res.status(401).json({
            msg: 'no token, authorize'
        });
    }

    try {
        const decoded = jwt.verify(token, constants.JWTSecret);
        req.user = decoded.userName;
        next();
    } catch(err) {
        return res.status(401).json({
            msg: 'token is not valid'
        });
    }
}

export default auth;
