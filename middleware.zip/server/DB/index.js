import mongoose from 'mongoose';

import constant from '../../constant';

const DB = () => {
    return (
        mongoose.connect(constant.mongoURI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useFindAndModify: true,
            useCreateIndex: true
        }).then(() => {
            console.log('db is connected');
        }).catch((err) => {
            console.log(err);
        })
    );
}

export default DB;
