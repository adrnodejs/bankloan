import express from 'express';
import { check, validationResult } from 'express-validator';

import BankSignup from '../schema/bankSignup';

let router = express.Router();

router.post('/', [
    check('userName', 'user name should not be empty').not().isEmpty(),
    check('password', 'password name should not be empty').not().isEmpty()
], async (req, res) => {
    try {
        const error = validationResult(req);
        if (!error.isEmpty()) {
            return res.status(400).json({
                error: error.array()
            })
        }
        const { userName, password } = req.body;
        let { role } = req.body;
        let RID = '';
        const user = await BankSignup.find({ userName });
        if (user && user.length) {
            return res.status(400).json({
                error: [{
                    mgs: "user already exits"
                }]
            })
        }
        if (role === 'R' || role === 'GM') {
            const relation = await BankSignup.find({ role });
            RID = relation.length + 1;
        }
        const newUser = new BankSignup({
            userName,
            password,
            role,
            managerId: RID
        });
        await newUser.save();
        return res.status(200).json({
            error: [{
                mgs: "usersaved sucessfully"
            }]
        })
    } catch (error) {
        return res.status(500).json({
            error: [{
                mgs: 'something went wrong'
            }]
        })
    }
});

module.exports = router;
