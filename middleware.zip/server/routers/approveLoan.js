import express from 'express';
import { check, validationResult } from 'express-validator';

import BankSignup from '../schema/bankSignup';
import auth from '../../middleware/auth';
import ApplyLoan from '../schema/loanStatus';

let router = express.Router();

router.get('/:id',[auth, [
    check('status', 'status should enter').not().isEmpty()
]], async (req, res) => {
    const userName = req.user;
    try {
        const error = validationResult(req);
        if (!error.isEmpty()) {
            return res.status(400).json({
                error: error.array()
            })
        }
        const user = await BankSignup.findOne({ userName });
        const approveLoan = await ApplyLoan.findById(req.params.id);
        if (user.role && user.role === 'R' && 
        approveLoan.status === 'waiting for approval' 
        && approveLoan.relationManager === user.userName) {
            const status = req.body.status === 'yes' ? 'waiting for GM approval' : "reject";
            await ApplyLoan.findByIdAndUpdate({ _id: req.params.id }, { status });
            return res.status(200).json({
                mgs: 'status updated'
            });
        } else if (user.role && user.role === 'GM' && approveLoan.status === 'waiting for GM approval') {
            const status = req.body.status === 'yes' ? 'approved' : "reject";
            await ApplyLoan.findByIdAndUpdate({ _id: req.params.id }, { status });
            return res.status(200).json({
                mgs: 'status updated'
            });
        }
    } catch (error) {
        return res.status(400).json({
            error: [{
                mgs: "something went wrong"
            }]
        })
    }
});

module.exports = router;
