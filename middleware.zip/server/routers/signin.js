import express from 'express';
import { check, validationResult } from 'express-validator';
import jwt from 'jsonwebtoken';

import constants from '../../constant';
import BankSignup from '../schema/bankSignup';

let router = express.Router();

router.post('/', [
    check('userName', 'user name should not be empty').not().isEmpty(),
    check('password', 'password name should not be empty').not().isEmpty()
], async (req, res) => {
    try {
        const error = validationResult(req);
        if (!error.isEmpty()) {
            return res.status(400).json({
                error: error.array()
            })
        }
        const { userName, password } = req.body;
        const user = await BankSignup.find({ userName });
        if (user && user.length < 0) {
            return res.status(400).json({
                error: [{
                    mgs: "user not exits"
                }]
            })
        }
        if (user[0].password !== password) {
            return res.status(400).json({
                error: [{
                    mgs: "password is incorrect"
                }]
            })
        }
        jwt.sign({ userName }, constants.JWTSecret, {
            expiresIn: 3600
        }, (err, token)=> {
            if (err) {
                throw err;
            }
            res.json({token})
        });
    } catch (error) {
        return res.status(500).json({
            error: [{
                mgs: 'something went wrong'
            }]
        })
    }
});

module.exports = router;
