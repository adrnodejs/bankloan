import express from 'express';
import { check, validationResult } from 'express-validator';

import BankSignup from '../schema/bankSignup';
import constants from '../../constant';
import auth from '../../middleware/auth';
import ApplyLoan from '../schema/loanStatus';

let router = express.Router();

router.get('/', [auth,[
    check('amount', 'amount should not be empty').not().isEmpty()
]], async (req, res) => {
    let relationManager = constants.bankManager;
    const { amount } = req.body;
    const userName = req.user;
    if (constants.bankManager <= 3) {
        constants.bankManager = constants.bankManager + 1;
    } else {
        constants.bankManager = 1;
    }
    try {
        const error = validationResult(req);
        if (!error.isEmpty()) {
            return res.status(400).json({
                error: error.array()
            })
        }
        const user = await BankSignup.findOne({ userName });
        const manager = await BankSignup.findOne({ managerId: relationManager, role: "R" });
        const Loan = new ApplyLoan({
            amount,
            relationManager: manager._id,
            userName: user._id
        });

        await Loan.save();
        return res.status(200).json({
            error: [{
                mgs: "loan applied sucessfully"
            }]
        })
    } catch (error) {
        return res.status(400).json({
            error: [{
                mgs: "something went wrong"
            }]
        })
    }
});

module.exports = router;
