import express from 'express';

import BankSignup from '../schema/bankSignup';
import auth from '../../middleware/auth';
import ApplyLoan from '../schema/loanStatus';

let router = express.Router();

router.get('/', auth, async (req, res) => {
    const userName = req.user;
    try {
        const user = await BankSignup.findOne({ userName });
        let loanList = '';
        if (user.role && user.role === 'R') {
            loanList = await ApplyLoan.find({ relationManager: user._id });
        } else if (user.role && user.role === 'GM') {
            loanList = await ApplyLoan.find({ status: 'approved by Relationship manager' });
        } else {
            loanList = await ApplyLoan.find({ userName: user._id });
        }
        return res.status(200).json(loanList);
    } catch (error) {
        return res.status(400).json({
            error: [{
                mgs: "something went wrong"
            }]
        })
    }
});

module.exports = router;
