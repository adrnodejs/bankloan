import { Schema, model, Mongoose } from 'mongoose';

const applyLoan = new Schema({
    userName: {
      type: Schema.Types.ObjectId,
      ref: 'bankSingup'
    },
    amount: {
        type: Number,
        required: true
    },
    status: {
        type: String
    },
    relationManager: {
        type: Schema.Types.ObjectId,
        ref: 'bankSingup'
    }
});

const ApplyLoan = model('applyLoain', applyLoan);

export default ApplyLoan;
