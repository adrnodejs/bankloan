import { Schema, model } from 'mongoose';

const bankSingup = new Schema({
    userName: {
        type: String,
        required: true,
        unique:true
    },
    password: {
        type: String,
        required: true
    },
    role: {
        type: String
    },
    managerId: {
        type: String
    }
});

const BankSignup = model('bankSingup', bankSingup);

export default BankSignup;
