import express from 'express';

import DB from './DB';

DB();

const app = express();
app.use(express.json({ extended: false }));

app.use('/signup', require('./routers/sinup'));
app.use('/signin', require('./routers/signin'));
app.use('/applyloan', require('./routers/userLoan'));
app.use('/loanList', require('./routers/LoanList'));
app.use('/loanApprove', require('./routers/approveLoan'));

app.listen(8080, ()=>{
    console.log('server is running');
});