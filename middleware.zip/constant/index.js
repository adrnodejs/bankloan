const constants = {
    JWTSecret: "sairama",
    bankManager: 1,
    mongoURI : 'mongodb://etejesh1:Sai%40teja@cluster0-shard-00-00-tpnpl.mongodb.net:27017,cluster0-shard-00-01-tpnpl.mongodb.net:27017,cluster0-shard-00-02-tpnpl.mongodb.net:27017/test?ssl=true&replicaSet=Cluster0-shard-0&authSource=admin&retryWrites=true&w=majority'
}

export default constants;